from django.contrib import admin  
from .models import (  
    Parcela, TipoCultivo, Cultivo, 
    RegistroCultivo, TipoRecurso, Recurso, Perfil
)

# Configuración para el modelo Parcela en el administrador
@admin.register(Parcela)
class ParcelaAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'area_total', 'ubicacion', 'tipo_suelo']  
    search_fields = ['nombre', 'ubicacion']  

# Configuración para el modelo TipoCultivo en el administrador
@admin.register(TipoCultivo)
class TipoCultivoAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'ciclo_vida']  
    search_fields = ['nombre']  

# Configuración para el modelo Cultivo en el administrador
@admin.register(Cultivo)
class CultivoAdmin(admin.ModelAdmin):
    list_display = ['tipo_cultivo', 'parcela', 'agricultor', 'estado', 'hectareas'] 
    list_filter = ['estado', 'tipo_cultivo'] 
    search_fields = ['parcela__nombre', 'agricultor__username']  

# Configuración para el modelo RegistroCultivo en el administrador
@admin.register(RegistroCultivo)
class RegistroCultivoAdmin(admin.ModelAdmin):
    list_display = ['cultivo', 'fecha', 'estado', 'altura', 'humedad'] 
    list_filter = ['fecha']  

# Configuración para el modelo TipoRecurso en el administrador
@admin.register(TipoRecurso)
class TipoRecursoAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'categoria', 'unidad_medida']  

# Configuración para el modelo Recurso en el administrador
@admin.register(Recurso)
class RecursoAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'agricultor', 'tipo_recurso', 'cantidad_total', 'costo_unitario'] 
    list_filter = ['tipo_recurso', 'agricultor']  
    search_fields = ['nombre']  

@admin.register(Perfil)
class PerfilAdmin(admin.ModelAdmin):
    list_display = ['user', 'cedula', 'fecha_nacimiento', 'telefono', 'direccion']
    search_fields = ['user__username']
    list_filter = ['fecha_nacimiento']
