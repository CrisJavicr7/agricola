import os
import django
import openai  # Importa OpenAI para la predicción

# Configuración del entorno Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'gestion_agricola.settings')
django.setup()

from agricultura.models import Cultivo, Parcela, TipoCultivo

# Configuración de la API de OpenAI
openai.api_key = "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"

def predecir_productividad(cultivo, tipo_suelo, precipitacion, temperatura, area_cultivo):
    """
    Realiza una predicción sobre la productividad utilizando OpenAI.
    """
    prompt = f"""
    Eres un modelo predictivo agrícola. Ayuda a estimar la productividad del cultivo basado en los siguientes datos:
    
    - Cultivo: {cultivo}
    - Tipo de Suelo: {tipo_suelo}
    - Precipitación Promedio: {precipitacion} mm
    - Temperatura Promedio: {temperatura} °C
    - Área de Cultivo: {area_cultivo} hectáreas
    
    Proporciona una estimación en toneladas por hectárea y una recomendación para mejorar la productividad.
    """
    try:
        # Actualización para usar el nuevo método con openai>=1.0.0
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Eres un experto en productividad agrícola."},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message['content']
    except Exception as e:
        return f"Error al realizar la predicción: {e}"

def generar_imagen(prompt, n=1, size="512x512"):
    """
    Genera imágenes utilizando la API de OpenAI.
    """
    try:
        response = openai.Image.create(
            prompt=prompt,
            n=n,
            size=size
        )
        # Imprime las URLs generadas en la consola para verificar
        imagenes = [img['url'] for img in response['data']]
        print(f"Imágenes generadas: {imagenes}")
        return imagenes
    except Exception as e:
        print(f"Error al generar la imagen: {e}")
        return []

if __name__ == "__main__":
    # Selecciona la funcionalidad a probar
    print("Selecciona qué deseas probar:")
    print("1: Predicción de productividad")
    print("2: Generación de imágenes")
    
    opcion = input("Ingresa 1 o 2: ")

    if opcion == "1":
        # Datos de ejemplo para la predicción
        cultivo = "Trigo"
        tipo_suelo = "Franco arenoso"
        precipitacion = 500
        temperatura = 22.5
        area_cultivo = 10

        print("\nRealizando predicción de productividad...")
        resultado = predecir_productividad(cultivo, tipo_suelo, precipitacion, temperatura, area_cultivo)
        print("Resultado de la predicción:")
        print(resultado)

    elif opcion == "2":
        # Prompt para la generación de imágenes
        prompt = "Un campo de trigo al amanecer con un cielo colorido"
        
        print("\nGenerando imagen...")
        imagenes = generar_imagen(prompt, n=1, size="512x512")
        
        if imagenes:
            print("Imágenes generadas:")
            for i, url in enumerate(imagenes):
                print(f"Imagen {i+1}: {url}")
        else:
            print("No se generaron imágenes.")

    else:
        print("Opción no válida. Finalizando programa.")
