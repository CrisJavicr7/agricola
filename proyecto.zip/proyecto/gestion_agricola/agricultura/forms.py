from django import forms
from .models import Cultivo, Parcela, Recurso, RegistroCultivo, TipoCultivo, TipoRecurso


class FormularioParcela(forms.ModelForm):

    class Meta:
        model=Parcela
        fields = '__all__'
        labels = {
            'nombre' : 'Nombre de la parcela',
            'area total' : 'Area total de la parcela',
            'ubicacion' : 'Ubicación de la parcela',
            'tipo de suelo' : 'Tipo de suelo de la parcela',
            'logo': 'Logo de la parcela'
            
        }
        
class FormularioCultivo(forms.ModelForm):
    
    class Meta:
        model = Cultivo
        fields = '__all__'
        labels = {
            'agricultor': 'Agricultor',
            'parcela': 'Parcela',
            'tipo_cultivo': 'Tipo de cultivo',
            'fecha_siembra': 'Fecha de siembra',
            'fecha_cosecha_estimada': 'Fecha de cosecha estimada',
            'estado': 'Estado',
            'hectareas': 'Hectáreas'
        }

class FormularioTipoCultivo(forms.ModelForm):
    
    class Meta:
        model = TipoCultivo
        fields = '__all__'
        labels = {
            'nombre': 'Nombre del tipo de cultivo',
            'descripcion': 'Descripción del tipo de cultivo',
            'ciclo_vida': 'Ciclo de vida del tipo de cultivo'
        }

class FormularioRegistroCultivo(forms.ModelForm):
    
    class Meta:
        model = RegistroCultivo
        fields = '__all__'
        labels = {
            'cultivo': 'Cultivo',
            'fecha': 'Fecha',
            'observacion': 'Observación',
            'estado': 'Estado',
            'altura': 'Altura',
            'humedad': 'Humedad'
        }

class FormularioTipoRecurso(forms.ModelForm):
    
    class Meta:
        model = TipoRecurso
        fields = '__all__'
        labels = {
            'nombre': 'Nombre del tipo de recurso'
        }
    
class FormularioRecurso(forms.ModelForm):
    
    class Meta:
        model = Recurso
        fields = '__all__'
        labels = {
            'nombre': 'Nombre del recurso',
            'tipo_recurso': 'Tipo de recurso',
            'cantidad': 'Cantidad',
            'fecha_compra': 'Fecha de compra',
            'precio': 'Precio',
            'observacion': 'Observación'
        }


from django import forms

class ClimaFormulario(forms.Form):
    ciudad = forms.CharField(max_length=100, required=False)
    latitud = forms.FloatField(required=False)
    longitud = forms.FloatField(required=False)

    def clean(self):
        cleaned_data = super().clean()
        ciudad = cleaned_data.get('ciudad')
        latitud = cleaned_data.get('latitud')
        longitud = cleaned_data.get('longitud')

        if not ciudad and (not latitud or not longitud):
            raise forms.ValidationError('Debe ingresar una ciudad o coordenadas.')

        return cleaned_data


class ClimaForm(forms.Form):
    ciudad = forms.CharField(label="Nombre de la ciudad", max_length=100, required=False)
    latitud = forms.FloatField(label="Latitud", required=False)
    longitud = forms.FloatField(label="Longitud", required=False)


class ClimaFormulario(forms.Form):
    ciudad = forms.CharField(max_length=100, required=False)
    latitud = forms.FloatField(required=False)
    longitud = forms.FloatField(required=False)

    def clean(self):
        cleaned_data = super().clean()
        ciudad = cleaned_data.get('ciudad')
        latitud = cleaned_data.get('latitud')
        longitud = cleaned_data.get('longitud')

        if not ciudad and (not latitud or not longitud):
            raise forms.ValidationError('Debe ingresar una ciudad o coordenadas.')

        return cleaned_data
