from django.db import models 
from django.contrib.auth.models import User  


class Parcela(models.Model):
    nombre = models.CharField(max_length=100)  
    area_total = models.FloatField()  
    ubicacion = models.CharField(max_length=200)  
    tipo_suelo = models.CharField(max_length=100)
    logo = models.ImageField(upload_to="parcela/logo", null=True, blank=True)


    def __str__(self):
        return self.nombre  

class TipoCultivo(models.Model):
    nombre = models.CharField(max_length=100)  
    descripcion = models.TextField()  
    ciclo_vida = models.CharField(max_length=100)  

    def __str__(self):
        return self.nombre  

class Cultivo(models.Model):
   
    ESTADOS_CHOICES = [
        ('PREPARACION', 'Preparación'),
        ('SIEMBRA', 'Siembra'),
        ('CRECIMIENTO', 'Crecimiento'),
        ('COSECHA', 'Cosecha'),
        ('FINALIZADO', 'Finalizado')
    ]

    agricultor = models.ForeignKey(User, on_delete=models.CASCADE) 
    parcela = models.ForeignKey(Parcela, on_delete=models.CASCADE)  
    tipo_cultivo = models.ForeignKey(TipoCultivo, on_delete=models.CASCADE) 
    fecha_siembra = models.DateField()  
    fecha_cosecha_estimada = models.DateField() 
    estado = models.CharField(max_length=20, choices=ESTADOS_CHOICES)  
    hectareas = models.FloatField()  

    def __str__(self):
        return f"{self.tipo_cultivo.nombre} - {self.parcela.nombre}"  


class RegistroCultivo(models.Model):
    cultivo = models.ForeignKey(Cultivo, on_delete=models.CASCADE) 
    fecha = models.DateField(auto_now_add=True)  
    observacion = models.TextField()  
    estado = models.CharField(max_length=100) 
    altura = models.FloatField(null=True, blank=True)  
    humedad = models.FloatField(null=True, blank=True)   

    def __str__(self):
        return f"Registro de {self.cultivo} - {self.fecha}"  

class TipoRecurso(models.Model):
    nombre = models.CharField(max_length=100)  
    unidad_medida = models.CharField(max_length=50) 
    categoria = models.CharField(max_length=100)  

    def __str__(self):
        return self.nombre  


class Recurso(models.Model):
    agricultor = models.ForeignKey(User, on_delete=models.CASCADE) 
    tipo_recurso = models.ForeignKey(TipoRecurso, on_delete=models.CASCADE)  
    nombre = models.CharField(max_length=100)  
    cantidad_total = models.FloatField()  
    costo_unitario = models.DecimalField(max_digits=10, decimal_places=2) 
    fecha_ultimo_reabastecimiento = models.DateField()  
    cultivos_asociados = models.ManyToManyField(Cultivo, blank=True) 

    def __str__(self):
        return self.nombre 
    

class Clima(models.Model):
    ciudad = models.CharField(max_length=100)
    temperatura = models.FloatField()
    humedad = models.FloatField()
    viento = models.FloatField()
    precipitacion = models.FloatField()
    fecha_registro = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Clima en {self.ciudad} en {self.fecha_registro}"

class RegistroProductividad(models.Model):
    cultivo = models.ForeignKey('Cultivo', on_delete=models.CASCADE)
    tipo_suelo = models.CharField(max_length=100)
    precipitacion = models.FloatField()
    temperatura = models.FloatField()
    area_cultivo = models.FloatField()

    def __str__(self):
        return f"{self.cultivo.tipo_cultivo.nombre} - {self.tipo_suelo} - {self.precipitacion}mm"


class Perfil(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    cedula = models.CharField(max_length=10)
    fecha_nacimiento = models.DateField()
    telefono = models.CharField(max_length=15)
    direccion = models.CharField(max_length=255)

    def __str__(self):
        return self.user.username