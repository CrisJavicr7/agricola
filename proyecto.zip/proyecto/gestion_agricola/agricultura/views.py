import datetime
from pyexpat.errors import messages
from django.shortcuts import redirect, render, get_object_or_404
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.template.loader import render_to_string
from io import BytesIO
from xhtml2pdf import pisa
import requests
from django.conf import settings
import openai  # Importa OpenAI para la predicción
import matplotlib
import matplotlib.pyplot as plt
import io
import base64
from agricultura.ai_predictions import predecir_productividad, generar_imagen
from agricultura.forms import (
    ClimaFormulario,
    FormularioCultivo,
    FormularioParcela,
    FormularioRecurso,
    FormularioRegistroCultivo,
    FormularioTipoCultivo,
    FormularioTipoRecurso
)
from agricultura.models import (
    Parcela,
    Cultivo,
    Recurso,
    RegistroCultivo,
    TipoCultivo,
    TipoRecurso,
    RegistroProductividad
)
matplotlib.use('Agg')
# Configuración de la API de OpenAI
openai.api_key = "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"

# Nueva vista para calcular productividad


@login_required
def calcular_productividad(request):
    resultado = None
    cultivos = Cultivo.objects.all()  # Obtén todos los cultivos registrados

    if request.method == 'POST':
        cultivo_id = request.POST.get('cultivo')  # Obtén el ID del cultivo seleccionado
        tipo_suelo = request.POST.get('tipo_suelo')
        precipitacion = request.POST.get('precipitacion')
        temperatura = request.POST.get('temperatura')
        area_cultivo = request.POST.get('area_cultivo')

        try:
            cultivo_obj = get_object_or_404(Cultivo, id=cultivo_id)  # Obtén el objeto cultivo

            # Guarda los datos ingresados en la base de datos
            RegistroProductividad.objects.create(
                cultivo=cultivo_obj,
                tipo_suelo=tipo_suelo,
                precipitacion=precipitacion,
                temperatura=temperatura,
                area_cultivo=area_cultivo,
            )

            # Llama a la función que hace la predicción
            resultado = predecir_productividad(
                cultivo=cultivo_obj.tipo_cultivo.nombre,
                tipo_suelo=tipo_suelo,
                precipitacion=precipitacion,
                temperatura=temperatura,
                area_cultivo=area_cultivo
            )

        except Exception as e:
            resultado = f"Error al realizar la predicción: {e}"

        return render(request, 'resultado_productividad.html', {'resultado': resultado})

    # Pasa los cultivos al template
    return render(request, 'calcular_productividad.html', {'cultivos': cultivos})


@login_required
def graficar_productividad(request):
    registros = RegistroProductividad.objects.all()  # Obtén todos los registros

    # Asegúrate de que haya datos para graficar
    if not registros.exists():
        return HttpResponse("No hay datos válidos para graficar.")

    cultivos = [registro.cultivo.tipo_cultivo.nombre for registro in registros]
    precipitaciones = [registro.precipitacion for registro in registros]  # Ejemplo: graficar precipitaciones
    temperaturas = [registro.temperatura for registro in registros]  # Puedes usar otros datos también

    # Crear gráfica
    plt.figure(figsize=(8, 6))
    plt.bar(cultivos, precipitaciones, label='Precipitación (mm)')
    plt.plot(cultivos, temperaturas, marker='o', color='red', label='Temperatura (°C)')
    plt.xlabel("Cultivo")
    plt.ylabel("Valores")
    plt.title("Productividad por Cultivo")
    plt.legend()

    # Guardar la gráfica en un buffer
    buffer = BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    plt.close()

    # Retornar la gráfica como respuesta HTTP
    return HttpResponse(buffer.getvalue(), content_type="image/png")


@login_required
def generar_imagen_view(request):
    if request.method == 'POST':
        prompt = request.POST.get('prompt')
        try:
            # Llama a la función generar_imagen para obtener la URL
            imagenes = generar_imagen(prompt, n=1, size="512x512")
            if imagenes:  # Si las imágenes fueron generadas con éxito
                url_imagen = imagenes[0]
                return render(request, 'resultado_imagen.html', {'url_imagen': url_imagen})
            else:  # Si no se generaron imágenes
                return render(request, 'resultado_imagen.html', {'url_imagen': None, 'error': 'No se pudo generar la imagen.'})
        except Exception as e:
            return render(request, 'resultado_imagen.html', {'url_imagen': None, 'error': f'Error al generar la imagen: {e}'})
    return redirect('calcular_productividad')


@login_required
def generar_pdf_parcelas(request):
    # Obtener datos de parcelas
    parcelas = Parcela.objects.all()
    fecha_actual = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Renderizar plantilla HTML con datos
    html = render_to_string('parcelas_pdf.html', {'parcelas': parcelas, 'fecha_actual': fecha_actual})

    # Crear respuesta HTTP
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="reporte_parcelas.pdf"'

    # Generar PDF
    pisa_status = pisa.CreatePDF(html, dest=response)

    # Manejar errores
    if pisa_status.err:
        return HttpResponse("Hubo un error al generar el PDF", status=500)

    return response


@login_required
def generar_pdf_cultivos(request):
    cultivos = Cultivo.objects.all()
    fecha_actual = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template_path = 'reporte_cultivos.html'
    context = {'cultivos': cultivos, 'fecha_actual': fecha_actual}
    
    # Crear una respuesta HTTP para un archivo PDF
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="reporte_cultivos.pdf"'
    
    # Renderizar el HTML a PDF
    template = render_to_string(template_path, context)
    pisa_status = pisa.CreatePDF(template, dest=response)
    
    # Comprobar si hay errores en la generación del PDF
    if pisa_status.err:
        return HttpResponse('Hubo un error al generar el PDF', status=500)
    
    return response


@login_required
def generar_pdf_recursos(request):
    recursos = Recurso.objects.all()
    fecha_actual = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template_path = 'reporte_recursos.html'
    context = {'recursos': recursos, 'fecha_actual': fecha_actual}
    
    # Crear una respuesta HTTP para un archivo PDF
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="reporte_recursos.pdf"'
    
    # Renderizar el HTML a PDF
    template = render_to_string(template_path, context)
    pisa_status = pisa.CreatePDF(template, dest=response)
    
    # Comprobar si hay errores en la generación del PDF
    if pisa_status.err:
        return HttpResponse('Hubo un error al generar el PDF', status=500)
    
    return response


@login_required
def listar_parcelas(request):
    parcelas = Parcela.objects.all()
    return render(request, 'listar_parcelas.html', {"parcelas": parcelas})


@login_required
def detalle_parcela(request, id_parcela):
    parcela = get_object_or_404(Parcela, id=id_parcela)
    cultivos = Cultivo.objects.filter(parcela=parcela)
    contexto = {
        "parcela": parcela,
        "cultivos": cultivos,
    }
    return render(request, 'detalle_parcela.html', contexto)


@login_required
def crear_parcela(request):
    if request.method == 'POST':
        formulario = FormularioParcela(request.POST, request.FILES)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_parcelas')
    else:
        formulario = FormularioParcela()
    
    return render(request, 'crear_parcela.html', {'formulario': formulario})


@login_required
def editar_parcela(request, id_parcela):
    parcela = get_object_or_404(Parcela, id=id_parcela)
    if request.method == 'POST':
        formulario = FormularioParcela(request.POST, request.FILES, instance=parcela)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_parcelas')
    else:
        formulario = FormularioParcela(instance=parcela)
    
    return render(request, 'editar_parcela.html', {'formulario': formulario})


@login_required
def eliminar_parcela(request, id_parcela):
    parcela = get_object_or_404(Parcela, id=id_parcela)
    parcela.delete()
    return redirect('listar_parcelas')


@login_required
def crear_cultivo(request):
    if request.method == 'POST':
        formulario = FormularioCultivo(request.POST, request.FILES)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_cultivos')
    else:
        formulario = FormularioCultivo()
    
    return render(request, 'crear_cultivo.html', {'formulario': formulario})


@login_required
def listar_cultivos(request):
    cultivos = Cultivo.objects.all()
    return render(request, 'listar_cultivos.html', {"cultivos": cultivos})


@login_required
def detalle_cultivo(request, id_cultivo):
    cultivo = get_object_or_404(Cultivo, id=id_cultivo)
    return render(request, 'detalle_cultivo.html', {"cultivo": cultivo})


@login_required
def editar_cultivo(request, id_cultivo):
    cultivo = get_object_or_404(Cultivo, id=id_cultivo)
    if request.method == 'POST':
        formulario = FormularioCultivo(request.POST, request.FILES, instance=cultivo)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_cultivos')
    else:
        formulario = FormularioCultivo(instance=cultivo)
    
    return render(request, 'editar_cultivo.html', {'formulario': formulario})


@login_required
def eliminar_cultivo(request, id_cultivo):
    cultivo = get_object_or_404(Cultivo, id=id_cultivo)
    cultivo.delete()
    return redirect('listar_cultivos')


@login_required
def listar_tipo_cultivos(request):
    tipo_cultivos = TipoCultivo.objects.all()
    return render(request, 'listar_tipo_cultivos.html', {"tipo_cultivos": tipo_cultivos})


@login_required
def detalle_tipo_cultivo(request, id_tipo_cultivo):
    tipo_cultivo = get_object_or_404(TipoCultivo, id=id_tipo_cultivo)
    return render(request, 'detalle_tipo_cultivo.html', {"tipo_cultivo": tipo_cultivo})


@login_required
def crear_tipo_cultivo(request):
    if request.method == 'POST':
        formulario = FormularioTipoCultivo(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_tipo_cultivos')
    else:
        formulario = FormularioTipoCultivo()
    
    contexto = {
        'formulario': formulario
    }

    return render(request, 'crear_tipo_cultivo.html', contexto)


@login_required
def editar_tipo_cultivo(request, id_tipo_cultivo):
    tipo_cultivo = get_object_or_404(TipoCultivo, id=id_tipo_cultivo)
    if request.method == 'POST':
        formulario = FormularioTipoCultivo(request.POST, instance=tipo_cultivo)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_tipo_cultivos')
    else:
        formulario = FormularioTipoCultivo(instance=tipo_cultivo)
    
    return render(request, 'editar_tipo_cultivo.html', {'formulario': formulario})


@login_required
def eliminar_tipo_cultivo(request, id_tipo_cultivo):
    tipo_cultivo = get_object_or_404(TipoCultivo, id=id_tipo_cultivo)
    tipo_cultivo.delete()
    return redirect('listar_tipo_cultivos')


@login_required
def listar_registro_cultivo (request):
    registros = RegistroCultivo.objects.all()
    return render(request, 'listar_registro_cultivo.html', {"registros": registros})


@login_required
def editar_registro_cultivo(request, id_registro_cultivo):
    registro = get_object_or_404(RegistroCultivo, id=id_registro_cultivo)
    if request.method == 'POST':
        formulario = FormularioRegistroCultivo(request.POST, instance=registro)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_registro_cultivos')
    else:
        formulario = FormularioRegistroCultivo(instance=registro)
    
    return render(request, 'editar_registro_cultivo.html', {'formulario': formulario})


@login_required
def eliminar_registro_cultivo(request, id_registro_cultivo):
    registro = get_object_or_404(RegistroCultivo, id=id_registro_cultivo)
    registro.delete()
    return redirect('listar_registro_cultivos')


@login_required
def crear_registro_cultivo(request):
    if request.method == 'POST':
        formulario = FormularioRegistroCultivo(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_registro_cultivos')
    else:
        formulario = FormularioRegistroCultivo()
    
    return render(request, 'crear_registro_cultivo.html', {'formulario': formulario})


@login_required
def listar_tipo_recursos(request):
    tipo_recursos = TipoRecurso.objects.all()
    return render(request, 'listar_tipo_recursos.html', {"tipo_recursos": tipo_recursos})


@login_required
def editar_tipo_recurso(request, id_tipo_recurso):
    tipo_recurso = get_object_or_404(TipoRecurso, id=id_tipo_recurso)
    if request.method == 'POST':
        formulario = FormularioTipoRecurso(request.POST, instance=tipo_recurso)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_tipo_recursos')
    else:
        formulario = FormularioTipoRecurso(instance=tipo_recurso)
    
    return render(request, 'editar_tipo_recurso.html', {'formulario': formulario})


@login_required
def eliminar_tipo_recurso(request, id_tipo_recurso):
    tipo_recurso = get_object_or_404(TipoRecurso, id=id_tipo_recurso)
    tipo_recurso.delete()
    return redirect('listar_tipo_recursos')


@login_required
def crear_tipo_recursos(request):
    if request.method == 'POST':
        formulario = FormularioTipoRecurso(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_tipo_recursos')
    else:
        formulario = FormularioTipoRecurso()
    
    return render(request, 'crear_tipo_recurso.html', {'formulario': formulario})


@login_required
def listar_recursos(request):
    recursos = Recurso.objects.all()
    return render(request, 'listar_recursos.html', {"recursos": recursos})


@login_required
def detalle_recurso(request, id_recurso):
    recurso = get_object_or_404(Recurso, id=id_recurso)
    return render(request, 'detalle_recurso.html', {"recurso": recurso})


@login_required
def editar_recurso(request, id_recurso):
    recurso = get_object_or_404(Recurso, id=id_recurso)
    if request.method == 'POST':
        formulario = FormularioRecurso(request.POST, instance=recurso)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_recursos')
    else:
        formulario = FormularioRecurso(instance=recurso)
    
    return render(request, 'editar_recurso.html', {'formulario': formulario}) 


@login_required
def eliminar_recurso(request, id_recurso):
    recurso = get_object_or_404(Recurso, id=id_recurso)
    recurso.delete()
    return redirect('listar_recursos')


@login_required
def crear_recurso(request):
    if request.method == 'POST':
        formulario = FormularioRecurso(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('listar_recursos')
    else:
        formulario = FormularioRecurso()
    return render(request, 'crear_recurso.html', {'formulario': formulario})
    



   
@login_required 
def obtener_clima_pronostico(request):
    clima = None
    clima_forecast = []
    formulario = ClimaFormulario()

    if request.method == 'POST':
        formulario = ClimaFormulario(request.POST)
        if formulario.is_valid():
            ciudad = formulario.cleaned_data['ciudad']
            latitud = formulario.cleaned_data.get('latitud')
            longitud = formulario.cleaned_data.get('longitud')

            
            if ciudad:
                url = f'https://api.openweathermap.org/data/2.5/weather?q={ciudad}&appid={settings.OPENWEATHERMAP_API_KEY}&units=metric'
            elif latitud and longitud:
                url = f'https://api.openweathermap.org/data/2.5/weather?lat={latitud}&lon={longitud}&appid={settings.OPENWEATHERMAP_API_KEY}&units=metric'
            else:
                return render(request, 'tiempo.html', {'form': formulario, 'error': 'Ingrese una ciudad o coordenadas.'})

            response = requests.get(url)
            data = response.json()

            
            if data.get('cod') == 200:
                
                clima = {
                    'ciudad': data['name'],
                    'temperatura': data['main']['temp'],
                    'humedad': data['main']['humidity'],
                    'viento': data['wind']['speed'],
                    'precipitacion': data['rain']['1h'] if 'rain' in data else 0,  # Manejo de precipitación
                    'descripcion': traducir_descripcion(data['weather'][0]['description']),
                    'latitud': data['coord']['lat'],
                    'longitud': data['coord']['lon']
                }
                
                
                forecast_url = f"https://api.agromonitoring.com/agro/1.0/weather/forecast?lat={clima['latitud']}&lon={clima['longitud']}&appid=0a8742a24580136e1e9a6344ea8b907c"
                forecast_response = requests.get(forecast_url)
                if forecast_response.status_code == 200:
                    forecast_data = forecast_response.json()
                    for item in forecast_data:
                        pronostico = {
                            'fecha': datetime.utcfromtimestamp(item['dt']).strftime('%d-%m-%Y %H:%M:%S'),
                            'temp_max': round(item['main']['temp_max'] - 273.15, 2),  # Convertir de Kelvin a Celsius
                            'temp_min': round(item['main']['temp_min'] - 273.15, 2),  # Convertir de Kelvin a Celsius
                            'descripcion': traducir_descripcion(item['weather'][0]['description'])
                        }
                        clima_forecast.append(pronostico)
            else:
                error = data.get('message', 'No se pudo obtener información climática.')
                return render(request, 'tiempo.html', {'form': formulario, 'error': error})

    context = {
        'form': formulario,
        'clima': clima,
        'clima_forecast': clima_forecast
    }

    return render(request, 'tiempo.html', context)


@login_required 
def traducir_descripcion(descripcion_en):
  
    traducciones = {
        "light rain": "lluvia ligera",
        "broken clouds": "nubes rotas",
        "scattered clouds": "nubes dispersas",
        "few clouds": "pocas nubes",
        "moderate rain":"lluvia moderada",
        "overcast clouds": "nubes cubiertas"
       
    }
    return traducciones.get(descripcion_en, descripcion_en)  


@login_required 
def unix_to_date(timestamp):
    return datetime.datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')

@login_required
def perfil(request):
    return render(request, 'perfil.html')