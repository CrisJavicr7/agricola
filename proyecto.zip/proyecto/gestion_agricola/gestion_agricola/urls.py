from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from agricultura.views import (
    obtener_clima_pronostico, listar_parcelas, detalle_parcela, 
    crear_parcela, editar_parcela, eliminar_parcela, listar_cultivos, detalle_cultivo, crear_cultivo, 
    editar_cultivo, eliminar_cultivo, listar_tipo_cultivos, detalle_tipo_cultivo, crear_tipo_cultivo, 
    editar_tipo_cultivo, eliminar_tipo_cultivo, listar_registro_cultivo, editar_registro_cultivo, 
    eliminar_registro_cultivo, crear_registro_cultivo, listar_tipo_recursos, editar_tipo_recurso, 
    eliminar_tipo_recurso, crear_tipo_recursos, listar_recursos, detalle_recurso, editar_recurso, 
    eliminar_recurso, crear_recurso, calcular_productividad, generar_imagen_view, graficar_productividad, 
    generar_pdf_parcelas, generar_pdf_cultivos, generar_pdf_recursos, perfil
)

urlpatterns = [
    path('admin/', admin.site.urls),

    # Rutas para parcelas
    path('parcelas/', listar_parcelas, name='listar_parcelas'),
    path('parcelas/<int:id_parcela>/', detalle_parcela, name='detalle_parcela'),
    path('parcelas/crear/', crear_parcela, name='crear_parcela'),
    path('parcelas/editar/<int:id_parcela>/', editar_parcela, name='editar_parcela'),
    path('parcelas/eliminar/<int:id_parcela>/', eliminar_parcela, name='eliminar_parcela'),

    # Rutas para cultivos
    path('cultivos/', listar_cultivos, name='listar_cultivos'),
    path('cultivos/<int:id_cultivo>/', detalle_cultivo, name='detalle_cultivo'),
    path('cultivos/crear/', crear_cultivo, name='crear_cultivo'),
    path('cultivos/editar/<int:id_cultivo>/', editar_cultivo, name='editar_cultivo'),
    path('cultivos/eliminar/<int:id_cultivo>/', eliminar_cultivo, name='eliminar_cultivo'),

    # Rutas para tipos de cultivos
    path('tipo_cultivos/', listar_tipo_cultivos, name='listar_tipo_cultivos'),
    path('tipo_cultivos/<int:id_tipo_cultivo>/', detalle_tipo_cultivo, name='detalle_tipo_cultivo'),
    path('tipo_cultivos/crear/', crear_tipo_cultivo, name='crear_tipo_cultivo'),
    path('tipo_cultivos/editar/<int:id_tipo_cultivo>/', editar_tipo_cultivo, name='editar_tipo_cultivo'),
    path('tipo_cultivos/eliminar/<int:id_tipo_cultivo>/', eliminar_tipo_cultivo, name='eliminar_tipo_cultivo'),

    # Rutas para registros de cultivos
    path('registros_cultivo/', listar_registro_cultivo, name='listar_registro_cultivos'),
    path('registros_cultivo/editar/<int:id_registro_cultivo>/', editar_registro_cultivo, name='editar_registro_cultivo'),
    path('registros_cultivo/eliminar/<int:id_registro_cultivo>/', eliminar_registro_cultivo, name='eliminar_registro_cultivo'),
    path('registros_cultivo/crear/', crear_registro_cultivo, name='crear_registro_cultivo'),

    # Rutas para tipos de recursos
    path('tipo_recursos/', listar_tipo_recursos, name='listar_tipo_recursos'),
    path('tipo_recursos/editar/<int:id_tipo_recurso>/', editar_tipo_recurso, name='editar_tipo_recurso'),
    path('tipo_recursos/eliminar/<int:id_tipo_recurso>/', eliminar_tipo_recurso, name='eliminar_tipo_recurso'),
    path('tipo_recursos/crear/', crear_tipo_recursos, name='crear_tipo_recursos'),

    # Rutas para recursos
    path('recursos/', listar_recursos, name='listar_recursos'),
    path('recursos/detalle/<int:id_recurso>/', detalle_recurso, name='detalle_recurso'),
    path('recursos/editar/<int:id_recurso>/', editar_recurso, name='editar_recurso'),
    path('recursos/eliminar/<int:id_recurso>/', eliminar_recurso, name='eliminar_recurso'),
    path('recursos/crear/', crear_recurso, name='crear_recurso'),

    # Rutas para cálculos y gráficos
    path('calcular-productividad/', calcular_productividad, name='calcular_productividad'),
    path('generar-imagen/', generar_imagen_view, name='generar_imagen'),
    path('graficar-productividad/', graficar_productividad, name='graficar_productividad'),

    # Rutas para generar PDF de parcelas, cultivos y recursos
    path('reportes/parcelas/', generar_pdf_parcelas, name='reporte_parcelas'),
    path('reportes/cultivos/', generar_pdf_cultivos, name='reporte_cultivos'),
    path('reportes/recursos/', generar_pdf_recursos, name='reporte_recursos'),

    # Rutas para obtener clima
    path('tiempo/', obtener_clima_pronostico, name='obtener_clima_pronostico'),

    path('accounts/', include('allauth.urls')),
    path('accounts/profile/', perfil),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    